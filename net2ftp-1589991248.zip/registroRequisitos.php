<?php
error_reporting(0);

$conexion = mysqli_connect("localhost","101927","tfgsergio","101927");

if(!$conexion)
{
  exit("Error al intentar conectarse al servidor.");
}

$edadMinima = $_POST["edadMinima"];
$edadMaxima = $_POST["edadMaxima"];
$requisitoDeGenero = $_POST["requisitoDeGenero"];
$reputacionNecesaria = $_POST["reputacionNecesaria"];

if(empty($edadMinima) || empty($edadMaxima) || empty($requisitoDeGenero) || empty($reputacionNecesaria))
{
  echo "perfecto. no habra requisitos.";
}
else
{

 if($reputacionNecesaria > 5)
  {
    echo "La reputacion no ha de excederse de los limites.";
  }
else
{
 $consulta = "INSERT INTO requisitos (edadMinima,edadMaxima,requisitoDeGenero,reputacionNecesaria) VALUES ('$edadMinima','$edadMaxima','$requisitoDeGenero','$reputacionNecesaria')";

 $result = mysqli_query($conexion,$consulta);

 echo "Registro completado con exito.";
}
}


mysqli_close($conexion);
?>