<?php
error_reporting(0);

$conexion = mysqli_connect("localhost","101927","tfgsergio","101927");

if(!$conexion)
{
  exit("Error al intentar conectarse al servidor.");
}

$organizadorEvento = $_POST["organizadorEvento"];
$deporte = $_POST["deporte"];
$localidad = $_POST["localidad"];
$direccion = $_POST["direccion"];
$fechaEvento = $_POST["fechaEvento"];
$horaEvento = $_POST["horaEvento"];
$maximoParticipantes = $_POST["maximoParticipantes"];
$instalacionesReservadas = $_POST["instalacionesReservadas"];
$costeEvento = $_POST["costeEvento"];
$precioPorParticipante = $_POST["precioPorParticipante"];
$comentarios = $_POST["comentarios"];
$terminado = $_POST["terminado"];

if(empty($organizadorEvento))
{
  echo "Debe rellenar el campo email.";
}
else
{
  if(!filter_var($organizadorEvento, FILTER_VALIDATE_EMAIL))
  {
    echo "Has de ingresar un correo con formato valido.";
  }
}

$fecha_actual = date('d-m-Y');
	
if(strtotime($fecha_actual) > strtotime($fechaEvento))
{
  echo "No puede seleccionar una fecha pasada";
}
else
{
   $consulta = "INSERT INTO eventos (organizadorEvento, deporte, localidad, direccion, fechaEvento, horaEvento,
    maximoParticipantes, instalacionesReservadas, costeEvento, precioPorParticipante, comentarios, terminado) VALUES ('$organizadorEvento','$deporte','$localidad','$direccion',
    '$fechaEvento','$horaEvento','$maximoParticipantes','$instalacionesReservadas','$costeEvento','$precioPorParticipante', '$comentarios','$terminado')";

  $result = mysqli_query($conexion,$consulta);

  echo "Registro completado con exito.";
}

mysqli_close($conexion);
?>			