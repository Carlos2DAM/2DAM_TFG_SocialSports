<?php
error_reporting(0);

$conexion = mysqli_connect("localhost","101927","tfgsergio","101927");

if(!$conexion)
{
  exit("Error al intentar conectarse al servidor.");
}
$email = $_POST["email"];
$contrasenia = $_POST["contrasenia"];
$reputacion = $_POST["reputacion"];

if(empty($email))
{
  echo "Debe rellenar el campo email.";
}
else
{
  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
    echo "Has de ingresar un correo con formato valido.";
  }
}

if(empty($contrasenia))
{
  echo "Debe rellenar el campo contrasenia.";
}
else
{
  if(strlen($contrasenia) > 8)
  {
    echo "La contrasenia ha de contener menos de 8 caracteres.";
  }
}

if(buscarRepes($email,$conexion)==1)
{
  echo "Este usuario ya existe.";
}
else
{
  $consulta = "INSERT INTO usuarios (email,contrasenia,reputacion) VALUES ('$email','$contrasenia','$reputacion')";
  $result = mysqli_query($conexion,$consulta);

if(!$result)
  {
     echo "Fallo en el registro.";
  }
  else
  {
     echo "Registro completado con exito.";
  }

}

mysqli_close($conexion);

function buscarRepes($email,$conexion)
{
  $comprobar = "SELECT * FROM usuarios WHERE email='$email'";
  $resultado = mysqli_query($conexion,$comprobar);

  if(mysqli_num_rows($resultado)>0)
  {
    return 1;
  }
  else
  {
    return 0;
  }
  mysqli_close($conexion);
}

?>			